CREATE TABLE geodb.test_20150707 (
	doc_id int(10) NOT NULL auto_increment,
	url varchar(255),
	regione varchar(50),
	provincia varchar(50),
	city varchar(50),
	indirizzo varchar(255),
	iva varchar(50),
	email varchar(255),
	telefono varchar(255),
	fax varchar(255),
	edificio varchar(1000),
	latitude varchar(255),
	longitude varchar(255),
	nazione varchar(50),
	description varchar(5000),
	postalCode varchar(1000),
	indirizzoNoCAP varchar(1000),
	indirizzoHasNumber varchar(1000),
	PRIMARY KEY (doc_id)
) ENGINE=InnoDB;
INSERT INTO geodb.test_20150707(doc_id, url, regione, provincia, city, indirizzo, iva, email, telefono, fax, edificio, latitude, longitude, nazione, description, postalCode, indirizzoNoCAP, indirizzoHasNumber) VALUES (1, 'http://4bid.it', 'Sardinia', null, null, 'Via Sorripa, 10', '06241710489', 'info@4bid.it', '0558228127', null, '4BID SRL ACCOMODATION BUSINESS GURU', '40.1208752', '9.012892599999999', 'Italia', null, '50026', 'Via Sorripa  ', '10');
