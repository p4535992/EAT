CREATE TABLE geodb.test_20150702 (
	doc_id int(10) NOT NULL auto_increment,
	url varchar(255),
	regione varchar(50),
	provincia varchar(50),
	city varchar(50),
	indirizzo varchar(255),
	iva varchar(50),
	email varchar(255),
	telefono varchar(255),
	fax varchar(255),
	edificio varchar(1000),
	latitude varchar(255),
	longitude varchar(255),
	nazione varchar(50),
	description varchar(5000),
	postalCode varchar(1000),
	indirizzoNoCAP varchar(1000),
	indirizzoHasNumber varchar(1000),
	PRIMARY KEY (doc_id)
) ENGINE=InnoDB;
INSERT INTO geodb.test_20150702(doc_id, url, regione, provincia, city, indirizzo, iva, email, telefono, fax, edificio, latitude, longitude, nazione, description, postalCode, indirizzoNoCAP, indirizzoHasNumber) VALUES (1, 'http://www.flavia.it/', null, null, null, null, null, null, null, null, 'FLAVIA', '45.6197129', '13.8108811', 'Italia', null, null, null, null);
INSERT INTO geodb.test_20150702(doc_id, url, regione, provincia, city, indirizzo, iva, email, telefono, fax, edificio, latitude, longitude, nazione, description, postalCode, indirizzoNoCAP, indirizzoHasNumber) VALUES (2, 'http://www.unifi.it', null, null, null, null, null, null, null, null, 'UNIFI UNIVERSIT� DEGLI STUDI DI FIRENZE UNIVERSIT� DEGLI STUDI DI FIRENZE', '43.798645', '11.253583', 'Italia', 'UniFI - Universit� degli Studi di Firenze', null, null, null);
